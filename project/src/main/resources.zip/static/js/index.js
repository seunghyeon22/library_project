const header = document.querySelector('header');
const nav = document.querySelector('nav');


nav.addEventListener('mouseover',function(){
    header.style.height = '270px';
})

nav.addEventListener('mouseout',function(){
    header.style.height = '80px';
})