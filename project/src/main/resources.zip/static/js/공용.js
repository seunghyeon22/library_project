
window.addEventListener("load",function(){
    const menuBtn = document.querySelector('.select_bar > ul > span');
    let menuList = document.querySelector('.select_bar > ul');

    menuBtn.addEventListener("hover",function(){
        menuList.classList.add("on");
    });

    menuBtn.addEventListener("dbclick",function(){
        menuList.classList.remove("on");
    });


});
